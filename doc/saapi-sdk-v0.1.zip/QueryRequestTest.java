
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.sa.sdk.builder.SAApi;
import com.sa.sdk.builder.ServiceBuilder;
import com.sa.sdk.exception.SAException;
import com.sa.sdk.request.QueryRequest;
import com.sa.sdk.response.SNSSearchResult;
import com.sa.sdk.response.ProfileSearchResponse;

public class QueryRequestTest {
	//thb Testing appKey;
	private String appKey = "403683db-47b1-4176-bf1a-03a92969bd51";
	//thb Testing appSecret;
	private String appSecret = "+7MOSZIxWCrvApI0QyAxDXl/QMvqiulP";
	
	private SAApi api = new SAApi(){

		@Override
		public String getAPIUrlAddress() {
			// API URL
			return "http://api.soanalytics.com/saapi";
		}
		
	};
	
	public void testSearchProfile(){
		ServiceBuilder builder = new ServiceBuilder(api, appKey, appSecret);
		try {
			QueryRequest request = (QueryRequest) builder.build(QueryRequest.class);
			
			ProfileSearchResponse result = request.getProfileSearchResponse("港股", "SINA", null, 1, 20, "pDate", "TW");
			
			System.out.println("Result Count: " + result.getResultCount());
			
			File file = new File("searchProfile.txt");
			FileWriter printer = new FileWriter(file);
			printer.write("Get Search Result: " + StringUtils.join(result.getResult(),","));
			printer.flush();
			printer.close();
			
		} catch (SAException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	
	public static void main(String args[]){
		QueryRequestTest test = new QueryRequestTest();
		
		Method[] methodList = test.getClass().getDeclaredMethods();
		
		try{
			for(Method method : methodList){
			
				if(method.getName().equals("main"))
					continue;
					
				System.out.println("Invoking method:" + method.getName());
				method.setAccessible(true);
				
				method.invoke(test);
			}
		} catch (Exception e){
			e.printStackTrace();
		}
		
		System.exit(0);
	}
}
