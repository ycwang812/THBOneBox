To compile test Program
javac -encoding UTF8 -cp .;lib/commons-codec-1.7.jar;lib/gson-2.2.2.jar;lib/jna-3.0.9.jar;lib/httpcore-4.2.2.jar;lib/commons-logging-1.1.1.jar;lib/commons-lang-2.6.jar;lib/httpclient-4.2.2.jar;SA-SDK.jar; QueryRequestTest.java

To run the test Program:
java -Dfile.encoding=utf8 -cp .;lib/commons-codec-1.7.jar;lib/gson-2.2.2.jar;lib/jna-3.0.9.jar;lib/httpcore-4.2.2.jar;lib/commons-logging-1.1.1.jar;lib/commons-lang-2.6.jar;lib/httpclient-4.2.2.jar;SA-SDK.jar QueryRequestTest